# Categorias principais
CATEGORIES = [
    {'name': 'Tendencias', 'action': 'list_tendencia', 'icon': 'trending.png', 'description': 'Explore filmes e séries tendencias da semana.'},
    {'name': 'Filmes', 'action': 'list_filmes', 'icon': 'filmes.png', 'description': 'Explore pela vasta extensão de filmes.'},
    {'name': 'Séries', 'action': 'list_series', 'tipo': 'series', 'icon': 'series.png', 'description': 'Descubra as séries, Desenhos, Animes e Novelas mais populares.'},
    {'name': '[COLOR yellow]Informações[/COLOR]', 'action': 'show_addon_info', 'icon': 'info.png', 'description': 'Detalhes sobre o addon.'},
]

SERIES_SUBCATEGORIES = [
    {'name': '[COLOR gold]Pesquisar[/COLOR]', 'action': 'search_router', 'icon': 'search.png', 'description': 'Opção para buscar filmes, séries e animes.'},
    {'name': 'Series', 'action': 'list_conteudo', 'tipo': 'series', 'icon': 'series.png', 'description': 'Descubra as séries mais populares.'},
    {'name': 'Animes', 'action': 'list_conteudo', 'tipo': 'animes', 'icon': 'animes.png', 'description': 'Descubra os animes mais populares.'},
    {'name': 'Novelas', 'action': 'list_conteudo', 'tipo': 'novelas', 'icon': 'novelas.png', 'description': 'Descubra as novelas mais populares.'},
    {'name': 'Desenhos', 'action': 'list_conteudo', 'tipo': 'desenhos', 'icon': 'desenhos.png', 'description': 'Descubra os desenhos mais populares.'}
]

FILMES_SUBCATEGORIES = [
    {'name': '[COLOR gold]Pesquisar[/COLOR]', 'action': 'search_router', 'icon': 'search.png', 'description': 'Opção para buscar filmes, séries e animes.'},
    {'name': 'Adicionados recentemente', 'url': 'https://raw.githubusercontent.com/Gael1303/flixroom/refs/heads/main/menu/movies/new.json', 'description': 'Filmes recentemente adicionados ao catálogo.'},
    {'name': 'Nos Cinemas', 'url': 'https://raw.githubusercontent.com/Gael1303/flixroom/refs/heads/main/menu/movies/cinema.json', 'description': 'Filmes em cartaz nos cinemas.'},
    {'name': 'Mais Populares (TMDb)', 'url': 'https://raw.githubusercontent.com/Gael1303/flixroom/refs/heads/main/menu/movies/popular', 'description': 'Filmes mais populares entre os usuários.'},
    {'name': '4K Ultra HD', 'url': 'https://raw.githubusercontent.com/Gael1303/flixroom/refs/heads/main/menu/movies/4k.json', 'description': 'Filmes disponíveis em resolução 4K Ultra HD.'},
    {'name': 'Por Gêneros', 'action': 'listar_generos', 'description': 'Explore filmes por gênero.'},
    {'name': 'Coleções', 'action': 'listar_colecoes', 'icon': 'colecoes.png', 'description': 'Descubra coleções de filmes organizadas por temas e franquias.'},
    {'name': 'Por Ano', 'action': 'listar_anos', 'icon': 'calendario.png', 'description': 'Descubra filmes lançados em anos específicos.'},
    {'name': 'Estudios', 'action': 'list_estudios', 'icon': 'animes.png', 'description': 'Explore os filmes de diferentes estúdios renomados, como Universal, Warner Bros, Disney, entre outros.'}
]

# Definindo a URL fora das funções
URL_TENDENCIA = "https://raw.githubusercontent.com/Gael1303/flixroom/refs/heads/main/menu/movies/tendencia.json"

# Definindo as URLs fora das funções
TVSHOWS_URLS = {
    "series": "https://raw.githubusercontent.com/Gael1303/flixroom/refs/heads/main/menu/tvshows/series.json",
    "novelas": "https://raw.githubusercontent.com/Gael1303/flixroom/refs/heads/main/menu/tvshows/novelas.json",
    "animes": "https://raw.githubusercontent.com/Gael1303/flixroom/refs/heads/main/menu/tvshows/animes.json",
    "desenhos": "https://raw.githubusercontent.com/Gael1303/flixroom/refs/heads/main/menu/tvshows/desenhos.json"
}

# URL definidas fora das funções
URL_FILMES = 'https://raw.githubusercontent.com/Gael1303/flixroom/refs/heads/main/menu/movies/popular'

# Definição da URL global para filmes por estúdio
URL_ESTUDIO = 'https://raw.githubusercontent.com/Gael1303/flixroom/refs/heads/main/menu/movies/popular'

# Definição da URL global para filmes por ano
URL_POR_ANO = "https://raw.githubusercontent.com/Gael1303/flixroom/refs/heads/main/menu/movies/popular"

# Definição da URL global para coleções de filmes
URL_COLECOES = "https://raw.githubusercontent.com/Gael1303/flixroom/refs/heads/main/menu/movies/collection.json"