import sys
import xbmcgui
import xbmcplugin

from resources.lib.utils import get_json_data, get_url
from resources.lib.menu import CATEGORIES, SERIES_SUBCATEGORIES, FILMES_SUBCATEGORIES

HANDLE = int(sys.argv[1])

def list_categories():
    """
    Lista as categorias principais na interface do Kodi, com descrição.
    """
    xbmcplugin.setContent(HANDLE, 'genres')
    xbmcplugin.setPluginCategory(HANDLE, 'Menu Principal')

    for category in CATEGORIES:
        list_item = xbmcgui.ListItem(label=category['name'])
        list_item.setArt({'icon': category['icon'], 'fanart': 'fanart.jpg'})
        list_item.setInfo('video', {'title': category['name'], 'genre': 'Menu', 'plot': category.get('description', 'Descrição não disponível')})

        url = get_url(action=category['action'], tipo=category['name'].lower())
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)

def list_subcategories(subcategories):
    xbmcplugin.setContent(HANDLE, 'genres')
    """
    Lista as subcategorias na interface do Kodi, com descrição.
    """
    for subcategory in subcategories:
        list_item = xbmcgui.ListItem(label=subcategory['name'])
        list_item.setArt({'icon': 'default.png', 'fanart': 'fanart.jpg'})
        list_item.setInfo('video', {'title': subcategory['name'], 'genre': 'Subcategoria', 'plot': subcategory.get('description', 'Descrição não disponível')})

        # Se a subcategoria tem 'action', gera a URL com 'action'
        action = subcategory.get('action')
        if action:
            # Para ações do tipo 'list_conteudo', adicionar o tipo de conteúdo
            if action == 'list_conteudo':
                url = get_url(action=action, tipo=subcategory['tipo'])
            else:
                url = get_url(action=action)  # Ajuste para passar o action da subcategoria
        else:
            # Caso contrário, usa a 'url' diretamente
            url = get_url(action='list_items', data_url=subcategory['url'], category_name=subcategory['name'])

        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)



def list_filmes():
    """
    Exibe as subcategorias de filmes.
    """
    list_subcategories(FILMES_SUBCATEGORIES)
    
def list_series():
    """
    Exibe as subcategorias de filmes.
    """
    list_subcategories(SERIES_SUBCATEGORIES)    
  

def list_animes():
    """
    Lista diretamente os itens da categoria Animes.
    """
    list_items(ANIMES_URL)
    