import sys
import xbmcgui
import xbmcplugin
import subprocess
import xbmc

from urllib.parse import parse_qsl

HANDLE = int(sys.argv[1])

def play_video(paths):
    """
    Reproduz um vídeo a partir de uma ou mais URLs fornecidas.
    """
    if isinstance(paths, list) and len(paths) > 1:
        dialog = xbmcgui.Dialog()

        # Define os nomes das fontes
        choices = [
            f"Fonte {i+1} - {'Torrent' if 'plugin://plugin.video.elementum' in path else 'Link Direto'}"
            for i, path in enumerate(paths)
        ]

        index = dialog.select("Escolha uma fonte", choices)

        if index == -1:
            return  # Se o usuário cancelar a seleção
        selected_path = paths[index]
    else:
        selected_path = paths if isinstance(paths, str) else paths[0]

    # Detecta o sistema operacional
    is_windows = xbmc.getCondVisibility("System.Platform.Windows")

    # Se for Windows, oferece a opção de escolher entre VLC e o player padrão do Kodi
    if is_windows and selected_path.startswith("https://"):
        dialog = xbmcgui.Dialog()
        choice = dialog.select(
            "Escolha o player", 
            ["VLC", "Player Padrão (Kodi)", "InputStream Adaptive (HLS/DASH)"]
        )

        if choice == -1:
            return  # Cancelou a escolha
        elif choice == 0:  # Escolheu o VLC
            vlc_path = r"C:\Program Files\VideoLAN\VLC\vlc.exe"  # Caminho do VLC
            if not os.path.exists(vlc_path):
                vlc_path = r"C:\Program Files (x86)\VideoLAN\VLC\vlc.exe"  # Tenta outra pasta
            if os.path.exists(vlc_path):
                user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36"
                command = [vlc_path, "--http-user-agent", user_agent, selected_path]
                try:
                    subprocess.Popen(command, shell=False)  # Abre no VLC
                    xbmc.log(f"Comando VLC executado: {command}", xbmc.LOGINFO)
                except Exception as e:
                    xbmcgui.Dialog().ok("Erro", f"Falha ao abrir no VLC: {str(e)}")
                    xbmc.log(f"Erro ao executar VLC: {str(e)}", xbmc.LOGERROR)
            else:
                message = "VLC não encontrado no caminho especificado.\n\nPor favor, instale o VLC."
                xbmcgui.Dialog().ok("Erro", message)
                xbmc.log("VLC não encontrado.", xbmc.LOGERROR)
            return  # Impede que o Kodi tente resolver a URL no player padrão

        elif choice == 1:  # Escolheu o player padrão (Kodi)
            play_item = xbmcgui.ListItem(offscreen=True)
            play_item.setPath(selected_path)
            xbmcplugin.setResolvedUrl(HANDLE, True, listitem=play_item)
            xbmc.log(f"Reproduzindo no player do Kodi: {selected_path}", xbmc.LOGINFO)

        elif choice == 2:  # Escolheu InputStream Adaptive (HLS/DASH)
            is_adaptive = xbmc.getCondVisibility("inputstream.adaptive")
            if not is_adaptive:
                xbmcgui.Dialog().ok("Erro", "InputStream Adaptive não está instalado.")
                return

            play_item = xbmcgui.ListItem(path=selected_path)
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')  # ou 'mpd' para DASH
            xbmcplugin.setResolvedUrl(HANDLE, True, listitem=play_item)
            xbmc.log(f"Reproduzindo com InputStream Adaptive: {selected_path}", xbmc.LOGINFO)

    else:
        is_adaptive = xbmc.getCondVisibility("System.HasAddon(inputstream.adaptive)")

        if is_adaptive and selected_path.startswith("http"):
            play_item = xbmcgui.ListItem(path=selected_path)
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')  # ou 'mpd' para DASH
            xbmcplugin.setResolvedUrl(HANDLE, True, listitem=play_item)
            xbmc.log(f"Reproduzindo com InputStream Adaptive: {selected_path}", xbmc.LOGINFO)

        else:
            play_item = xbmcgui.ListItem(offscreen=True)
            play_item.setPath(selected_path)
            xbmcplugin.setResolvedUrl(HANDLE, True, listitem=play_item)
            xbmc.log(f"Reproduzindo no player do Kodi: {selected_path}", xbmc.LOGINFO)

    # Garantir que o fluxo de navegação volte para o diretório anterior após a reprodução
    xbmcplugin.endOfDirectory(HANDLE)
