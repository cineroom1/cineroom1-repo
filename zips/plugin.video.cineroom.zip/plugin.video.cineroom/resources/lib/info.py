import sys
import xbmcgui
import xbmcplugin

# Aqui voce cria as informaçoes do addon    
def show_addon_info():
    info = (
        "[B][COLOR gold]Cineroom Addon[/COLOR][/B]\n\n"
        "Versão: 4.1\n"
        "Desenvolvedor: Gael\n"
        "Lançado em: 17/01/2025\n\n"
        "Descrição:\n"
        "Explore filmes e séries com qualidade e praticidade.\n\n"
        "Links:\n"
        "[B][COLOR gold]Telegram[/COLOR][/B]: t.me/Cineroom1\n"
        "[B][COLOR gold]Index Github[/COLOR][/B]: https://cineroom1.github.io\n"
        "[B][COLOR gold]Doação[/COLOR][/B]: cineroom.ofc@gmail.com\n"
    )
    xbmcgui.Dialog().textviewer("Informações do Addon", info)

