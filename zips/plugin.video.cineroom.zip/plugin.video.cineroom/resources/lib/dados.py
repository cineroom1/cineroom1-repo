# Gêneros de filmes
GENRES = [
    {'name': 'Ação', 'key': 'Ação'},
    {'name': 'Animação', 'key': 'Animação'},
    {'name': 'Aventura', 'key': 'Aventura'}, 
    {'name': 'Cinema TV', 'key': 'Cinema TV'},
    {'name': 'Comédia', 'key': 'Comédia'},
    {'name': 'Crime', 'key': 'Crime'},
    {'name': 'Documentário', 'key': 'Documentário'},
    {'name': 'Drama', 'key': 'Drama'},
    {'name': 'Fantasia', 'key': 'Fantasia'}, 
    {'name': 'Faroeste', 'key': 'Faroeste'},
    {'name': 'Ficção Científica', 'key': 'Ficção científica'},
    {'name': 'Família', 'key': 'Família'},
    {'name': 'Guerra', 'key': 'Guerra'},
    {'name': 'História', 'key': 'História'},
    {'name': 'Mistério', 'key': 'Mistério'}, 
    {'name': 'Música', 'key': 'Música'},
    {'name': 'Nacional', 'key': 'Nacional'},
    {'name': 'Romance', 'key': 'Romance'},
    {'name': 'Terror', 'key': 'Terror'},
    {'name': 'Thriller', 'key': 'Thriller'}
]

# Estúdios de filmes e séries predefinidos
ESTUDIOS_FILMES = [
    "Universal Pictures", 
    "Warner Bros.",
    "Paramount Pictures",
    "Sony Pictures",
    "20th Century Studios", 
    "Walt Disney Pictures",
    "Pixar", "DreamWorks Animation",
    "Columbia Pictures",
    "Legendary Pictures", 
    "DC Comics", "A24", 
    "Marvel Studios",
    "MGM", "Lionsgate",
    "New Line Cinema",
    "Original Film", 
    "Fox 2000 Pictures", 
    "Sunday Night Productions", 
    "Blue Sky Studios",
    "Lucasfilm Ltd.", 
    "Blumhouse Productions",
    "Skydance Media", 
    "Studio Ghibli"
]
