import sys
import xbmcgui
import xbmcplugin
import xbmcaddon
from urllib.request import urlopen
import json

from resources.lib.filmes import list_items  # Importando a função modularizada
from resources.lib.utils import get_json_data, get_url

HANDLE = int(sys.argv[1])


def search_router(paramstring):
    """
    Roteia a pesquisa para filmes ou séries.
    """
    from urllib.parse import parse_qsl
    params = dict(parse_qsl(paramstring))
    query = params.get('query')  # Obtém o termo de pesquisa

    if not query:
        # Solicita o termo de pesquisa ao usuário se não for fornecido
        query = xbmcgui.Dialog().input('Digite o termo de pesquisa')

    if query:
        # Permite que o usuário escolha a categoria (filmes ou séries) para pesquisar
        category = xbmcgui.Dialog().select('Escolha a categoria', ['Filmes', 'Séries'])

        if category != -1:
            category = 'filmes' if category == 0 else 'series'
            search_items(query, category)  # Chama a função de pesquisa para a categoria escolhida
        else:
            xbmcgui.Dialog().ok('Erro', 'Nenhuma categoria selecionada.')

def search_items(query, category):
    """
    Função de pesquisa que permite buscar filmes e séries por um termo.
    :param query: Termo de pesquisa fornecido pelo usuário.
    :param category: Categoria para a qual a pesquisa será realizada ('filmes' ou 'series').
    """
    xbmcplugin.setContent(HANDLE, 'videos' if category == 'filmes' else 'tvshows')

    # URLs para filmes e séries
    filmes_subcategories_urls = [
        'https://raw.githubusercontent.com/Gael1303/flixroom/refs/heads/main/menu/movies/popular'
    ]
    
    series_urls = {
        "series": "https://raw.githubusercontent.com/Gael1303/flixroom/refs/heads/main/menu/tvshows/series.json",
        "novelas": "https://raw.githubusercontent.com/Gael1303/flixroom/refs/heads/main/menu/tvshows/novelas.json",
        "animes": "https://raw.githubusercontent.com/Gael1303/flixroom/refs/heads/main/menu/tvshows/animes.json",
        "desenhos": "https://raw.githubusercontent.com/Gael1303/flixroom/refs/heads/main/menu/tvshows/desenhos.json"
    }

    try:
        if category == 'filmes':
            all_filmes = []
            unique_ids = set()

            for url in filmes_subcategories_urls:
                response = urlopen(url)
                filmes = json.loads(response.read().decode('utf-8'))

                for filme in filmes:
                    if query.lower() in filme['title'].lower():
                        tmdb_id = filme.get('tmdb_id')

                        if tmdb_id and tmdb_id not in unique_ids:
                            unique_ids.add(tmdb_id)
                            all_filmes.append(filme)

            for filme in all_filmes:
                list_item = xbmcgui.ListItem(label=filme['title'])
                list_item.setArt({'poster': filme['poster'], 'fanart': filme['backdrop']})
                list_item.setInfo('video', {
                    'title': filme['title'],
                    'plot': filme.get('synopsis', 'Sem descrição'),
                    'rating': filme.get('rating', 'N/A'),
                    'year': filme.get('year', 'Desconhecido'),
                    'studio': filme.get('studio', 'Desconhecido'),
                    'genre': filme.get('genres', 'N/A'),
                    'duration': filme.get('runtime', 'N/A'),
                    'mpaa': filme.get('premiered', 'N/A'),
                    'mediatype': 'movie'
                })

                list_item.setProperty('IsPlayable', 'true')
                urls = filme['url'] if isinstance(filme['url'], list) else [filme['url']]
                url = get_url(action='play', video=json.dumps(urls))
                xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=False)

        elif category == 'series':
            found_episodes = []

            for tipo, url in series_urls.items():
                response = urlopen(url)
                series = json.loads(response.read().decode('utf-8'))

                for serie in series:
                    if query.lower() in serie.get('title', '').lower():
                        found_episodes.append({
                            'type': 'serie',
                            'title': serie['title'],
                            'poster': serie['poster'],
                            'backdrop': serie['backdrop'],
                            'sinopse': serie.get('sinopse', 'Sem descrição'),
                            'rating': serie.get('rate', 'N/A'),
                            'studio': serie.get('studio', 'Desconhecido'),
                            'genres': serie.get('genres', 'N/A'),
                            'classification': serie.get('classification', 'N/A'),
                            'url': get_url(action='listar_temporadas', serie=serie['title'], tipo=tipo)
                        })

                    for temporada in serie.get('temporadas', []):
                        for episodio in temporada.get('episodios', []):
                            if query.lower() in episodio['title'].lower():
                                found_episodes.append({
                                    'type': 'episodio',
                                    'title': f"{serie['title']} - {episodio['title']}",
                                    'poster': temporada.get('poster', serie['poster']),
                                    'backdrop': serie['backdrop'],
                                    'sinopse': serie.get('sinopse', 'Sem descrição'),
                                    'rating': serie.get('rate', 'N/A'),
                                    'studio': serie.get('studio', 'Desconhecido'),
                                    'genres': serie.get('genres', 'N/A'),
                                    'classification': serie.get('classification', 'N/A'),
                                    'url': json.dumps([episodio['url']])
                                })

            for item in found_episodes:
                list_item = xbmcgui.ListItem(label=item['title'])
                list_item.setArt({'poster': item['poster'], 'fanart': item['backdrop']})
                list_item.setInfo('video', {
                    'title': item['title'],
                    'plot': item['sinopse'],
                    'rating': item['rating'],
                    'studio': item['studio'],
                    'genre': item['genres'],
                    'mpaa': item['classification'],
                    'mediatype': 'episode' if item['type'] == 'episodio' else 'tvshow'
                })

                if item['type'] == 'episodio':
                    list_item.setProperty('IsPlayable', 'true')
                    xbmcplugin.addDirectoryItem(handle=HANDLE, url=get_url(action='play', video=item['url']), listitem=list_item, isFolder=False)
                else:
                    xbmcplugin.addDirectoryItem(handle=HANDLE, url=item['url'], listitem=list_item, isFolder=True)

        xbmcplugin.endOfDirectory(HANDLE)

    except Exception as e:
        xbmcgui.Dialog().ok('Erro', f'Não foi possível realizar a pesquisa: {str(e)}')