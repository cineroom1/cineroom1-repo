import sys
import json
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from urllib.parse import parse_qsl

# Importação de módulos personalizados
from resources.lib.filmes import (
    list_items, listar_generos, carregar_dados_filmes, filmes_por_genero,
    list_estudios, filmes_por_estudio, listar_anos, filmes_por_ano,
    listar_colecoes, listar_filmes_colecao
)
from resources.lib.utils import get_json_data, get_url
from resources.lib.player import play_video
from resources.lib.info import show_addon_info
from resources.lib.search import search_router
from resources.lib.menu import CATEGORIES, SERIES_SUBCATEGORIES, FILMES_SUBCATEGORIES
from resources.lib.dados import GENRES, ESTUDIOS_FILMES
from resources.lib.categories import (
    list_categories, list_subcategories, list_filmes, list_series, list_animes
)

# Impotação de series
from resources.lib.series import (
    list_tendencia, list_seasons, list_episodes, list_conteudo,
    listar_temporadas, listar_episodios
)

# Configuração do addon
addon_handle = int(sys.argv[1])
addon = xbmcaddon.Addon()
URL = sys.argv[0]
HANDLE = int(sys.argv[1])


def router(paramstring):
    """
    Roteador para determinar a ação com base nos parâmetros fornecidos.
    :param paramstring: String de parâmetros da URL
    """
    params = dict(parse_qsl(paramstring))
    action = params.get('action')

    if action == "list_estudios":
        list_estudios()
    elif action == "filmes_por_estudio":
        filmes_por_estudio(paramstring)
    elif action == "listar_generos":
        listar_generos()
    elif action == "filmes_por_genero":
        genero = params.get("genero")
        if genero:
            filmes_por_genero(genero)
        else:
            xbmc.log("[Addon] Gênero não especificado.", xbmc.LOGWARNING)
    elif action == "listar_colecoes":
        listar_colecoes()
    elif action == "listar_filmes_colecao":
        collection_id = params.get("collection_id")
        listar_filmes_colecao(collection_id)
    elif action == 'listar_anos':
        listar_anos()
    elif action == 'filmes_por_ano':
        ano = params.get('ano')
        if ano:
            filmes_por_ano(ano)
        else:
            xbmc.log("[Addon] Ano não especificado para 'filmes_por_ano'.", xbmc.LOGWARNING)
    elif action == 'list_filmes':
        list_filmes()
    elif action == 'list_series':
        list_series()
    elif action == 'list_conteudo':
        tipo = params.get('tipo')
        if tipo:
            list_conteudo(tipo)
        else:
            xbmc.log("[Addon] Tipo de conteúdo não fornecido para 'list_conteudo'.", xbmc.LOGWARNING)
    elif action == 'listar_temporadas':
        serie_nome = params.get('serie')
        tipo = params.get('tipo')
        if serie_nome and tipo:
            listar_temporadas(serie_nome, tipo)
        else:
            xbmc.log("[Addon] Nome da série ou tipo não fornecido para 'listar_temporadas'.", xbmc.LOGWARNING)
    elif action == 'listar_episodios':
        serie_nome = params.get('serie')
        temporada_nome = params.get('temporada')
        tipo = params.get('tipo')
        if serie_nome and temporada_nome and tipo:
            listar_episodios(serie_nome, temporada_nome, tipo)
        else:
            xbmc.log("[Addon] Faltando parâmetros para 'listar_episodios'.", xbmc.LOGWARNING)
    elif action == 'list_tendencia':
        category_name = params.get('category_name', 'Tendências')
        list_tendencia(category_name)
    elif action == 'list_seasons':
        serie_nome = params.get('serie')
        if serie_nome:
            list_seasons(serie_nome)
        else:
            xbmc.log("[Addon] Nome da série não fornecido para 'list_seasons'.", xbmc.LOGWARNING)
    elif action == 'list_episodes':
        serie_nome = params.get('serie')
        temporada_nome = params.get('temporada')
        if serie_nome and temporada_nome:
            list_episodes(serie_nome, temporada_nome)
        else:
            xbmc.log("[Addon] Nome da série ou temporada não fornecido para 'list_episodes'.", xbmc.LOGWARNING)
    elif action == 'list_items':
        data_url = params.get('data_url')
        category_name = params.get('category_name')
        page = int(params.get('page', 1))
        if data_url and category_name:
            list_items(data_url, category_name, page)
        else:
            xbmc.log("[Addon] Faltando parâmetros para 'list_items'.", xbmc.LOGWARNING)
    elif action == 'search_router':
        search_router(paramstring)
    elif action == 'play':
        video_urls = params.get('video')
        if video_urls:
            video_urls = json.loads(video_urls)
            play_video(video_urls)
        else:
            xbmc.log("[Addon] URL do vídeo não fornecida para 'play'.", xbmc.LOGWARNING)
    elif action == 'show_addon_info':
        show_addon_info()
    else:
        list_categories()

if __name__ == '__main__':
    router(sys.argv[2][1:])
